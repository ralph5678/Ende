# Ende v0.9 local-competition ranking

Pairwise ranking over true-contact pairs versus one structurally/endpoint-descriptor-nearest negative from the same complex and 4.5–6 Å shell. Distance is excluded from model input.

Important limitation: the available cache does not retain residue IDs, so this is not a literal residue-neighborhood competitor benchmark. It is an endpoint-descriptor/local-complex competition control.
